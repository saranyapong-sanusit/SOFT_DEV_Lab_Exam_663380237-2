package kku.cp.softdev.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import kku.cp.softdev.model.Customer;

@Repository
public interface CustomerRepository extends JpaRepository<Customer, Long> {
}
