package kku.cp.softdev.controller;


import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import kku.cp.softdev.model.Order;
import kku.cp.softdev.service.OrderService;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/api/orders")
public class OrderController {
    private final OrderService orderService;

    public OrderController(OrderService orderService) {
        this.orderService = orderService;
    }

    // GET /api/orders
    @GetMapping
    public List<Order> getAll() {
        return orderService.getAll();
    }

    // GET /api/orders/{id}
    @GetMapping("/{id}")
    public ResponseEntity<Order> getById(@PathVariable Long id) {
        return orderService.getById(id)
                .map(ResponseEntity::ok)
//                ถ้าไม่เจอ Order ให้ส่ง HTTP 404 Not Found และ ไม่มี body
                .orElse(ResponseEntity.notFound().build());     
    }

    // POST /api/orders
    @PostMapping
    public ResponseEntity<Order> create(@RequestBody Order order) {
        Order saved = orderService.create(order);ม่
        return ResponseEntity.created(URI.create("/api/orders/" + saved.getId())).body(saved); 
        // object ของ order ที่เพิ่งจะบันทึกลง db
}

    // PUT /api/orders/{id}
    @PutMapping("/{id}")
    public ResponseEntity<Order> update(@PathVariable Long id, @RequestBody Order order) {
        try {
            Order updated = orderService.update(id, order);
            return ResponseEntity.ok(updated);
        } catch (RuntimeException ex) {
            return ResponseEntity.notFound().build();
        }
    }

    // DELETE /api/orders/{id}
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        orderService.delete(id);
        return ResponseEntity.noContent().build();//ลบข้อมูลสำเร็จ แต่ไม่มีข้อมูลส่งกลับ
    }
}
