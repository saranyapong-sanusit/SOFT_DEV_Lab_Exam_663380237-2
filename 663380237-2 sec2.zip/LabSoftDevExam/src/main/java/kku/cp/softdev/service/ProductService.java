package kku.cp.softdev.service;

import org.springframework.stereotype.Service;

import kku.cp.softdev.model.Product;
import kku.cp.softdev.repository.ProductRepository;

import java.util.List;
import java.util.Optional;

@Service
public class ProductService {
    private final ProductRepository productRepository;

    public ProductService(ProductRepository productRepository) {
        this.productRepository = productRepository;
    }

    public List<Product> getAll() { 
    	return productRepository.findAll(); 
    }
    public Optional<Product> getById(Long id) { 
    	return productRepository.findById(id); 
    }
    public Product create(Product p) { 
    	return productRepository.save(p); 
    }
    public Product update(Long id, Product newP) {
        return productRepository.findById(id).map(p -> {
            p.setName(newP.getName());
            p.setPrice(newP.getPrice());
            return productRepository.save(p);
        }).orElseThrow(() -> new RuntimeException("Product not found: " + id));
    }
    public void delete(Long id) { productRepository.deleteById(id); }
}
