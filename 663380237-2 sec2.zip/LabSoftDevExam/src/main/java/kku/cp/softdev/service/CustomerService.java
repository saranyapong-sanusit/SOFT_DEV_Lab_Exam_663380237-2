package kku.cp.softdev.service;


import org.springframework.stereotype.Service;

import kku.cp.softdev.model.Customer;
import kku.cp.softdev.repository.CustomerRepository;

import java.util.List;
import java.util.Optional;

@Service
public class CustomerService {
    private final CustomerRepository customerRepository;

    public CustomerService(CustomerRepository customerRepository) {
        this.customerRepository = customerRepository;
    }

    public List<Customer> getAll() { 
    	return customerRepository.findAll(); 
    }
    public Optional<Customer> getById(Long id) { 
    	return customerRepository.findById(id); 
    }
    public Customer create(Customer c) { 
    	return customerRepository.save(c); 
    }
    public Customer update(Long id, Customer newC) {
        return customerRepository.findById(id).map(c -> {
            c.setName(newC.getName());
            c.setEmail(newC.getEmail());
            return customerRepository.save(c);
        }).orElseThrow(() -> new RuntimeException("Customer not found: " + id));
    }
    public void delete(Long id) { customerRepository.deleteById(id); }
}
