package kku.cp.softdev.service;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import kku.cp.softdev.model.Customer;
import kku.cp.softdev.model.Order;
import kku.cp.softdev.model.OrderLine;
import kku.cp.softdev.model.Product;
import kku.cp.softdev.repository.CustomerRepository;
import kku.cp.softdev.repository.OrderRepository;
import kku.cp.softdev.repository.ProductRepository;

import java.util.List;
import java.util.Optional;

@Service
public class OrderService {
    private final OrderRepository orderRepository;
    private final CustomerRepository customerRepository;
    private final ProductRepository productRepository;

    public OrderService(OrderRepository orderRepository,
                        CustomerRepository customerRepository,
                        ProductRepository productRepository) {
        this.orderRepository = orderRepository;
        this.customerRepository = customerRepository;
        this.productRepository = productRepository;
    }

    public List<Order> getAll() {
        return orderRepository.findAll();
    }

    public Optional<Order> getById(Long id) {
        return orderRepository.findById(id);
    }

    public List<Order> findByCustomerId(Long customerId) {
        return orderRepository.findByCustomerId(customerId);
    }

    @Transactional
    public Order create(Order order) {

        if (order.getCustomer() != null && order.getCustomer().getId() != null) {
//        	ถ้ามี id ดึง Customer จากฐานข้อมูล
            Customer c = customerRepository.findById(order.getCustomer().getId())
//            	ถ้าไม่เจอ จะโยน exception
                    .orElseThrow(() -> new RuntimeException("Customer not found: " + order.getCustomer().getId()));
//            	ถ้าเจอ นำ Customer จาก DB ไปใส่ใน Order
            order.setCustomer(c);
        } else {
            if (order.getCustomer() != null) {
//            	บันทึก Customer ใหม่ลงฐานข้อมูล
                Customer saved = customerRepository.save(order.getCustomer());
                order.setCustomer(saved);
            }
        }

        if (order.getOrderLines() != null) {
            for (OrderLine line : order.getOrderLines()) {
//            	ถ้า OrderLine มี Product และ Product มี id → หา Product จากฐานข้อมูล
                if (line.getProduct() != null && line.getProduct().getId() != null) {
                    Product p = productRepository.findById(line.getProduct().getId())
                            .orElseThrow(() -> new RuntimeException("Product not found: " + line.getProduct().getId()));
                    line.setProduct(p);
                } else if (line.getProduct() != null) {
//                	สร้าง Product ใหม่ใน DB แล้วใส่ใน OrderLine
                    Product savedP = productRepository.save(line.getProduct());
                    line.setProduct(savedP);
                } else {
                    throw new RuntimeException("OrderLine.product is required");
                }
//                เชื่อม OrderLine กับ Order
                line.setOrder(order);
            }
        }
//       		บันทึก Order พร้อม OrderLines ทั้งหมดลงฐานข้อมูล
        return orderRepository.save(order);
    }

    @Transactional
    public Order update(Long id, Order newOrder) {
        Order order = orderRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Order not found: " + id));

        order.setOrderDate(newOrder.getOrderDate());
//        		ถ้า newOrder มี Customer และมี id 
        if (newOrder.getCustomer() != null) {
            if (newOrder.getCustomer().getId() != null) {
//            		หา Customer จาก DB แล้วใส่ใน Order
                Customer c = customerRepository.findById(newOrder.getCustomer().getId())
                        .orElseThrow(() -> new RuntimeException("Customer not found"));
                order.setCustomer(c);
            } else {
//            		ถ้า Customer ไม่มี id ให้สร้าง Customer ใหม่ใน DB แล้วใส่ใน  Order
                Customer saved = customerRepository.save(newOrder.getCustomer());
                order.setCustomer(saved);
            }
        }

//      			 ลบ OrderLines เดิม
        order.getOrderLines().clear();
        if (newOrder.getOrderLines() != null) {
            for (OrderLine ln : newOrder.getOrderLines()) {
//            		ถ้า product มี id
                if (ln.getProduct() != null && ln.getProduct().getId() != null) {
//                		หา Product ใน DB
                    Product p = productRepository.findById(ln.getProduct().getId())
                            .orElseThrow(() -> new RuntimeException("Product not found: " + ln.getProduct().getId()));
                    ln.setProduct(p);
//                  	 ถ้า Product ไม่มี id
                } else if (ln.getProduct() != null) {
                    Product savedP = productRepository.save(ln.getProduct());
                    ln.setProduct(savedP);
                } else {
                    throw new RuntimeException("OrderLine.product is required");
                }
//                		เชื่อม OrderLine กับ Order
                ln.setOrder(order);
//              		 เพิ่ม OrderLine เข้าใน Order
                order.getOrderLines().add(ln);
            }
        }
//      			บันทึก Order พร้อม OrderLines ใหม่ลง DB
        return orderRepository.save(order);
    }

    public void delete(Long id) {
        orderRepository.deleteById(id);
    }
}
